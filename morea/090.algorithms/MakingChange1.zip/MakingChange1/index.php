<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        $amount = 57;
        $quarters = (int) ($amount/25);
        $leftover = $amount - $quarters*25;
        $dimes = (int) ($leftover/10);
        $leftover = $leftover - $dimes*10;
        $nickles = (int) ($leftover/5);
        $pennies  = $leftover - $nickles*5;
                 
        printf('Quarters:%d Dimes:%d Nickles:%d Pennies:%d', $quarters, $dimes, $nickles, $pennies);
        
        ?>
    </body>
</html>
