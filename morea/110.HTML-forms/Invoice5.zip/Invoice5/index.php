<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // product data 
        $products[1] = array('item' => 'Gillette Sensor 3 Razor',
            'quantity' => 2,
            'price' => 1.23);

        $products[2] = array('item' => 'Barbasol Shaving Cream',
            'quantity' => 1,
            'price' => 2.64);

        $products[3] = array('item' => 'Nautica Cologne',
            'quantity' => 1,
            'price' => 6.17);

        $products[4] = array('item' => 'Rubbing Alcohol',
            'quantity' => 3,
            'price' => 0.98);

        $products[5] = array('item' => 'Colgate Classic Toothbrush',
            'quantity' => 12,
            'price' => 1.89);

        // var_dump($items, $quantities, $prices);
        if(array_key_exists('update_submit', $_POST)) {
            process_invoice($products, FALSE);
        } else {
            process_invoice($products);
        }
        ?>

    </body>
</html>

<?php

function process_invoice($products, $updatable = TRUE) {

    $num_prods = count($products);
    $subtotal = 0;
    for ($i = 1; $i <= $num_prods; $i++) {
        if (isset($_POST['quantity' . $i])) {
            $products[$i]['quantity'] = $_POST["quantity$i"];
        }
        // compute extended prices[s]
        $extended_prices[$i] = $products[$i]['price'] * $products[$i]['quantity'];
        // compute sub-total
        $subtotal = $subtotal + $extended_prices[$i];
    }

    // compute tax
    $tax_rate = 0.0575; // %5.75
    $tax = $tax_rate * $subtotal;

    // compute shipping 
    // $2 for subtotal < $50
    // $5 for subtotal < $100
    // >= $100 5% or subtotal
    if ($subtotal < 50) {
        $shipping = 2;
    } elseif ($subtotal < 100) {
        $shipping = 5;
    } else {
        $shipping = 0.05 * $subtotal;
    }

    // compute total
    $total = $subtotal + $tax + $shipping;

    // display invoice
    ?>

    <table style="border-collapse: inherit; width: 514px; height: 319px;" border="2" bordercolor="BLACK" cellpadding="0" cellspacing="0">
        <tbody>
            <tr>
                <td align="center" width="43%">
                    <b>
                        Item
                    </b>
                </td>
                <td width="11%">
                    <b>
                        quantity
                    </b>
                </td>
                <td style="text-align: center;" width="13%">
                    <b>
                        price
                    </b>
                </td>
                <td style="text-align: center;" width="54%">
                    <b>
                        extended price
                    </b>
                </td>
            </tr>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <?php
            for ($i = 1; $i <= $num_prods; $i++) {
                // item row 1
                if($updatable) {
                    $qty_str = '<input type=text name=quantity%d value=%d size=4>';
                } else {
                    $qty_str = '%d';
                }
                printf('
    <tr>
      <td width="43%%">
        %s
      </td>
      <td align="center" width="11%%">
        ' . $qty_str . '
      </td>
      <td style="text-align: center;" width="13%%">
        $ %.2f
      </td>
      <td style="text-align: center;" width="54%%">
        $ %.2f
      </td>
    </tr>
    ', $products[$i]['item'], $i, $products[$i]['quantity'], $products[$i]['price'], $extended_prices[$i]);
            }
            if($updatable) {
            ?>
            <tr><td colspan="4" align="center"><input type="submit" name="update_submit" value="Update Quantity"></td></tr>
            <?php 
            }
            ?>
        </form>
        <tr>
            <td colspan="4" width="100%">
                &nbsp;
            </td>
        </tr>
        <tr>
            <td colspan="3" width="67%">
                Sub-total
            </td>
            <td style="text-align: center;" width="54%">
                $ <?php printf('%.2f', $subtotal); ?>
            </td>
        </tr>
        <tr>
            <td colspan="3" width="67%">

                <font face="arial">
                Tax @ 5.75%
                </font>
            </td>
            <td style="text-align: center;" width="54%">
                $ <?php printf('%.2f', $tax); ?>
            </td>
        </tr>
        <tr>
            <td colspan="3" width="67%">

                <font face="arial">
                Shipping
                </font>
            </td>
            <td style="text-align: center;" width="54%">
                $ <?php printf('%.2f', $shipping); ?>
            </td>
        </tr>
        <tr>
            <td colspan="3" width="67%">
                <b>
                    Total
                </b>
            </td>
            <td style="text-align: center;" width="54%">
                <b>
                    $<?php printf('%.2f', $total); ?>
                </b>
            </td>
        </tr>
    </tbody>
    </table>
    <?php
}
