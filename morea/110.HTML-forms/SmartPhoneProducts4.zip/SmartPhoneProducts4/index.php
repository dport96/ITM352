<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // product data
        // http://dport96.github.io/ITM352/morea/090.flow-control-II/
        $prod1 = array( 'image' => "HTC.jpg", 
         'brand' => "HTC Phones", 
         'price' => 40);

        $prod2 = array( 'image' => "iphone-3gs.jpg", 
         'brand' => "Apple Phones", 
         'price' => 75);

        $prod3 = array( 'image' => "Nokia.jpg", 
         'brand' => "Nokia Phones", 
         'price' => 35);

        $prod4 = array( 'image' => "Samsung.jpg", 
         'brand' => "Samsung Phones", 
         'price' => 45);

        $prod5 = array( 'image' => "Blackberry.jpg", 
         'brand' => "Blackberry Phones", 
         'price' => 10);
        
$products = array($prod1,$prod2, $prod3, $prod4, $prod5); 

?>
        <!DOCTYPE html>
    <!--
    To change this license header, choose License Headers in Project Properties.
    To change this template file, choose Tools | Templates
    and open the template in the editor.
    -->
    <html>
        <head>
            <title>ITM352 Used Smartphone Store</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body>
        <center>
            <h1> Welcome to the ITM352 Used Smartphone Mart</h1>
            <table border="1">
                <tbody>
                    <tr>
                        <td style="text-align: center;"><b><big>Product</big></b></td>
                        <td style="text-align: center;"><b><big>Brand</big></b></td>
                        <td style="text-align: center;"><b><big>Price
                                    (each)</big></b></td>
                    </tr>
                    <?php
              
                    for ($i = 0; $i < count($products); $i++) {
                        printf('
                    <tr>
                        <td><img alt="Small" id="lightboxImage"
                                 style="width: 119px; height: 88px;"
                                 src="http://dport96.github.io/ITM352/morea/090.flow-control-II/%s"
                                 height="300" width="300"></td>
                        <td style="text-align: center;">%s</td>
                        <td style="text-align: center;">$%.2f</td>
                    </tr>
                            ', $products[$i]['image'], $products[$i]['brand'],$products[$i]['prices']);
                    }
                    ?>
                </tbody>
            </table>
        </center>
    </body>
</html>

</body>
</html>
