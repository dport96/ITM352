<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        $day = 26;
        $month = 'November';
        $year = 1993; // must be between 1900-2000
        // choose last 2 digits of birth year 
        $step1 = $year - 1900;
        $step2 = (int) ($step1/4);
        $step3 = $step1 + $step2;
        $step4 = $month2key[$month];
        // get month key number for month
            if($month == 'January') $step4 = 1;
            if($month == 'February') $step4 = 4;
            if($month == 'March') $step4 = 4;
            if($month == 'April') $step4 = 0;
            if($month == 'May') $step4 = 2;
            if($month == 'June') $step4 =5;
            if($month == 'July') $step4 = 0;
            if($month == 'August') $step4 = 3;
            if($month == 'September') $step4 = 6;
            if($month == 'October') $step4 = 1;
            if($month == 'November') $step4 = 4;
            if($month == 'December') $step4 = 6;

    
        $step5 = $step4 + $step3;
        $step6 = $day + $step5;
        $step7 = $step6 % 7;
        $step8 = $num2Day[$step7];
        // get day of week from week number
          if($step7 == 1) $step8 = 'Sunday';
          if($step7 == 2) $step8 = 'Monday';
          if($step7 == 3) $step8 = 'Tuesday';
          if($step7 == 4) $step8 = 'Wednsday';
          if($step7 == 5) $step8 = 'Thursday';
          if($step7 == 6) $step8 = 'Friday';
          if($step7 == 0) $step8 = 'Saturday';
        
       printf('%s %d, %d was a %s', $month, $day, $year, $step8);
        
        
        ?>
    </body>
</html>