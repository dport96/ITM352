<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // data 
        $x = 1.23;
        $y = 4.56;
/*
        printf('%.6f %s %.6f = %.6f<br>', $x, '+', $y, $result = $x + $y);

        printf('%.6f %s %.6f = %.6f<br>', $result, '/', $x, $result /= $x*$x);

        printf('%.6f %s %.6f = %.6f<br>', $result, 'x', $result, $result *= $result);

        printf('%.6f %s %.6f = %.6f<br>', $result, '-', (int) $result, $result -= (int) $result);
 * 
 */
        ?>

        <table style="border-collapse: inherit; width: 514px;" border="0" bordercolor="BLACK" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td align="center" width="43%" colspan="5">
                        <b>
                            PHP Calc
                        </b>
                    </td>
                </tr>
                <?php
                // calc rows
                printf('<tr><td>%.6f</td><td>%s</td><td>%.6f</td><td>=</td><td>%.6f</td></tr>', $x, '+', $y, $result = $x + $y);
                printf('<tr><td>%.6f</td><td>%s</td><td>%.6f</td><td>=</td><td>%.6f</td></tr>', $result, 'x', $result, $result *= $result);
                printf('<tr><td>%.6f</td><td>%s</td><td>%.6f</td><td>=</td><td>%.6f</td></tr>', $result, '/', $y+$x, $result /= $y+$x);
                printf('<tr><td>%.6f</td><td>%s</td><td>%.6f</td><td>=</td><td>%.6f</td></tr>',$result, '-', (int) $result, $result -= (int) $result);
                ?> 

            </tbody>
        </table>
    </body>
</html>