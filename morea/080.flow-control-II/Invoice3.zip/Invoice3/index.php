<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // product data 
        $item1 = 'Gillette Sensor 3 Razor';
        $quantity1 = 2;
        $price1 = 1.23;
        
        $item2 = 'Barbasol Shaving Cream';
        $quantity2 = 1;
        $price2 = 2.64;
        
        $item3 = 'Nautica Cologne';
        $quantity3 = 1;
        $price3 = 6.17;
        
        $item4 = 'Rubbing Alcohol';
        $quantity4 = 3;
        $price4 = 0.98;
        
        $item5 = 'Colgate Classic Toothbrush';
        $quantity5 = 12;
        $price5 = 1.89;       
        
        $num_prods = 5;
        $subtotal = 0;
        
       // loop for invoce calculations. This could also be done in the loop that
       // prints the invoice item rows
        for($i=1; $i<=$num_prods; $i++) {
        // compute extended prices
            $extended_price_ident =  'extended_price' . $i;
            $quantity_ident = 'quantity' . $i;
            $price_ident = 'price' . $i;
            $$extended_price_ident = $$price_ident * $$quantity_ident;
            // compute sub-total
            $subtotal = $subtotal + $$extended_price_ident;
        }
        
        // compute tax
        $tax_rate = 0.0575; // %5.75
        $tax = $tax_rate * $subtotal;
       
        // compute shipping 
        // $2 for subtotal < $50
        // $5 for subtotal < $100
        // >= $100 5% or subtotal
        if($subtotal < 50) {
            $shipping = 2;
        }
        elseif($subtotal < 100) {
            $shipping = 5;
        }
        else {
            $shipping = 0.05*$subtotal;
        }
        
       // compute total
       $total = $subtotal + $tax + $shipping;
        
        // display invoice
        ?>
        
        <table style="border-collapse: inherit; width: 514px; height: 319px;" border="2" bordercolor="BLACK" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td align="center" width="43%">
        <b>
          Item
        </b>
      </td>
      <td width="11%">
        <b>
          quantity
        </b>
      </td>
      <td style="text-align: center;" width="13%">
        <b>
          price
        </b>
      </td>
      <td style="text-align: center;" width="54%">
        <b>
          extended price
        </b>
      </td>
    </tr>
    <?php
    for($i=1; $i<=$num_prods; $i++) {
        $item_ident = 'item' . $i;
                    $extended_price_ident =  'extended_price' . $i;
            $quantity_ident = 'quantity' . $i;
            $price_ident = 'price' . $i;
    // item row 1
    printf('
    <tr>
      <td width="43%%">
        %s
      </td>
      <td align="center" width="11%%">
        %d
      </td>
      <td style="text-align: center;" width="13%%">
        $ %.2f
      </td>
      <td style="text-align: center;" width="54%%">
        $ %.2f
      </td>
    </tr>
    ', $$item_ident, $$quantity_ident, $$price_ident, $$extended_price_ident);
    
    }
 
    ?>
    <tr>
      <td colspan="4" width="100%">
        &nbsp;
      </td>
    </tr>
    <tr>
      <td colspan="3" width="67%">
        Sub-total
      </td>
      <td style="text-align: center;" width="54%">
        $ <?php printf('%.2f', $subtotal); ?>
      </td>
    </tr>
    <tr>
      <td colspan="3" width="67%">
        
        <font face="arial">
          Tax @ 5.75%
        </font>
      </td>
      <td style="text-align: center;" width="54%">
        $ <?php printf('%.2f', $tax); ?>
      </td>
    </tr>
        <tr>
      <td colspan="3" width="67%">
        
        <font face="arial">
          Shipping
        </font>
      </td>
      <td style="text-align: center;" width="54%">
        $ <?php printf('%.2f', $shipping); ?>
      </td>
    </tr>
    <tr>
      <td colspan="3" width="67%">
        <b>
          Total
        </b>
      </td>
      <td style="text-align: center;" width="54%">
        <b>
          $<?php printf('%.2f', $total); ?>
        </b>
      </td>
    </tr>
  </tbody>
</table>
    </body>
</html>