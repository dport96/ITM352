<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // product data
        // http://dport96.github.io/ITM352/morea/090.flow-control-II/
        $image1 = "HTC.jpg";
        $brand1 = "HTC Phones";
        $price1 = 40;

        $image2 = "iphone-3gs.jpg";
        $brand2 = "Apple Phones";
        $price2 = 75;

        $image3 = "Nokia.jpg";
        $brand3 = "Nokia Phones";
        $price3 = 35;

        $image4 = "Samsung.jpg";
        $brand4 = "Samsung Phones";
        $price4 = 45;

        $image5 = "Blackberry.jpg";
        $brand5 = "Blackberry Phones";
        $price5 = 10;
        ?>

        <!DOCTYPE html>
    <!--
    To change this license header, choose License Headers in Project Properties.
    To change this template file, choose Tools | Templates
    and open the template in the editor.
    -->
    <html>
        <head>
            <title>ITM352 Used Smartphone Store</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body>
        <center>
            <h1> Welcome to the ITM352 Used Smartphone Mart</h1>
            <table border="1">
                <tbody>
                    <tr>
                        <td style="text-align: center;"><b><big>Product</big></b></td>
                        <td style="text-align: center;"><b><big>Brand</big></b></td>
                        <td style="text-align: center;"><b><big>Price
                                    (each)</big></b></td>
                    </tr>
                    <?php
                    $num_prods = 5;
                    for ($i = 1; $i <= $num_prods; $i++) {
                        $image_ident = 'image' . $i;
                        $brand_ident = 'brand' . $i;
                        $price_ident = 'price' . $i;
                        printf('
                    <tr>
                        <td><img alt="Small" id="lightboxImage"
                                 style="width: 119px; height: 88px;"
                                 src="http://dport96.github.io/ITM352/morea/090.flow-control-II/%s"
                                 height="300" width="300"></td>
                        <td style="text-align: center;">%s</td>
                        <td style="text-align: center;">$%.2f</td>
                    </tr>
                            ', $$image_ident, $$brand_ident,$$price_ident);
                    }
                    ?>
                </tbody>
            </table>
        </center>
    </body>
</html>

</body>
</html>
